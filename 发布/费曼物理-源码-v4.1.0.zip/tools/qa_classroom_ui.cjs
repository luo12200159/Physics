const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { launchBrowser } = require("./browser-launcher.cjs");

const project = path.resolve(__dirname, "..");
const outputDirectory = path.join(project, "qa-output", "classroom-ui");
const classId = "11111111-1111-4111-8111-111111111111";
const createdClassId = "88888888-8888-4888-8888-888888888888";
const membershipId = "22222222-2222-4222-8222-222222222222";
const groupId = "33333333-3333-4333-8333-333333333333";
const inviteCode = "AbCdEfGhIjKlMnOpQrStUv";
const accessToken = `access.${"x".repeat(100)}`;
const refreshToken = `r1.44444444-4444-4444-8444-444444444444.${"a".repeat(43)}`;
const ownerCapability = `oc1.${"o".repeat(43)}`;
const ownerUserId = "99999999-9999-4999-8999-999999999999";
const sharedWork = { assignments: [], submissions: [], reviews: [] };
const shellSource = fs.readFileSync(path.join(project, "experience-shell.js"), "utf8");
assert.match(shellSource, /classSubmissionsLoaded/);
assert.match(shellSource, /提交记录读取失败，当前不计算均分、未交人数或知识点表现/);

function experience(role) {
  return {
    version: 2,
    onboarded: true,
    role,
    displayName: role === "teacher" ? "验收教师" : "验收学生",
    grade: "九年级",
    textbook: "人教版",
    goal: "中考",
    examDate: "",
    weeklyGoal: 12,
    studentExternalLinks: false,
    fontScale: 1,
    events: [],
    activeDates: []
  };
}

async function installActivationStub(page) {
  await page.route("**/activation.js", async (route) => {
    await route.fulfill({
      contentType: "text/javascript; charset=utf-8",
      body: `(() => {
        const whenActivated = Promise.resolve({ licenseId: "classroom-ui-qa", expiresAt: 0 });
        window.PhysicsStudioActivation = Object.freeze({
          version: "classroom-ui-qa",
          whenActivated,
          validateCode: async () => true,
          formatDeviceRequest: (value) => String(value || ""),
          publicKeyFingerprint: "classroom-ui-qa"
        });
        const unlock = () => {
          document.body.classList.remove("activation-pending");
          document.body.classList.add("activation-complete");
        };
        document.readyState === "loading"
          ? document.addEventListener("DOMContentLoaded", unlock, { once: true })
          : unlock();
      })();`
    });
  });
}

function json(route, status, body) {
  return route.fulfill({
    status,
    contentType: "application/json; charset=utf-8",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Authorization, Content-Type, Idempotency-Key, X-Physics-Studio-Client",
      "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS"
    },
    body: body == null ? "" : JSON.stringify(body)
  });
}

async function installServerMock(page, role, calls) {
  let memberStatus = "pending";
  let groups = [];
  let classes = role === "teacher" ? [] : [{
    id: classId,
    name: "九年级物理一班",
    grade: "九年级",
    subject: "物理",
    schoolLabel: "验收学校",
    status: "active",
    revision: 1,
    createdAt: "2026-08-01T00:00:00.000Z",
    updatedAt: "2026-08-01T00:00:00.000Z"
  }];
  await page.route("https://classroom.example/**", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const method = request.method();
    if (method === "OPTIONS") return json(route, 204, null);
    const headers = request.headers();
    const body = request.postDataJSON?.() || null;
    calls.push({ method, path: url.pathname, headers, body });
    if (url.pathname === "/v1/auth/login" && method === "POST") {
      return json(route, 200, {
        accessToken,
        refreshToken,
        user: {
          id: role === "teacher" ? "55555555-5555-4555-8555-555555555555" : "66666666-6666-4666-8666-666666666666",
          role,
          displayName: role === "teacher" ? "服务端教师" : "服务端学生",
          status: "active",
          mustChangePassword: false,
          deletionPending: false
        }
      });
    }
    if (url.pathname === "/v1/classes" && method === "GET") {
      return json(route, 200, {
        items: classes,
        nextCursor: null
      });
    }
    if (url.pathname === "/v1/classes" && method === "POST") {
      const created = {
        id: createdClassId,
        name: body.name,
        grade: "高一",
        subject: "物理",
        schoolLabel: null,
        status: "active",
        revision: 1,
        createdAt: "2026-08-08T00:00:00.000Z",
        updatedAt: "2026-08-08T00:00:00.000Z"
      };
      classes = [created, ...classes];
      return json(route, 201, created);
    }
    if (url.pathname === "/v1/classes/anonymous" && method === "POST") {
      const created = {
        id: createdClassId,
        name: body.name,
        grade: "高一",
        subject: "物理",
        schoolLabel: null,
        status: "active",
        revision: 1,
        createdAt: "2026-08-08T00:00:00.000Z",
        updatedAt: "2026-08-08T00:00:00.000Z"
      };
      classes = [created, ...classes];
      return json(route, 201, {
        class: created,
        ownerUserId,
        ownerCapability,
        ownerCapabilityExpiresAt: "2027-08-08T00:00:00.000Z"
      });
    }
    const activeClassId = [classId, createdClassId].find((id) => url.pathname.startsWith(`/v1/classes/${id}/`));
    const selectedClass = classes.find((item) => url.pathname === `/v1/classes/${item.id}`);
    if (selectedClass && method === "GET") return json(route, 200, selectedClass);
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/roster` && method === "GET") {
      return json(route, 200, {
        items: [{
          id: membershipId,
          classId,
          groupId: groups[0]?.id || null,
          userId: "66666666-6666-4666-8666-666666666666",
          displayName: "待审核学生",
          memberRole: "student",
          studentNumber: "2026001",
          status: memberStatus,
          revision: 1,
          joinedAt: "2026-08-01T00:00:00.000Z",
          updatedAt: "2026-08-01T00:00:00.000Z"
        }],
        nextCursor: null
      });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/groups` && method === "GET") {
      return json(route, 200, { items: groups, nextCursor: null });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/groups` && method === "POST") {
      groups = [{ id: groupId, classId: activeClassId, name: body.name, revision: 1, createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z" }];
      return json(route, 201, groups[0]);
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/assignments` && method === "GET") {
      return json(route, 200, { items: sharedWork.assignments, nextCursor: null });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/assignments` && method === "POST") {
      const item = {
        ...body,
        id: "44444444-4444-4444-8444-444444444444",
        classId: activeClassId,
        status: body.publish ? "published" : "draft",
        revision: 1,
        questionItems: (body.questionItems || []).map(({ correctAnswer: _answer, ...question }) => question),
        createdAt: "2026-10-23T12:00:00.000Z",
        updatedAt: "2026-10-23T12:00:00.000Z"
      };
      sharedWork.assignments.push(item);
      return json(route, 201, item);
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/assignment-submissions` && method === "GET") {
      return json(route, 200, { items: sharedWork.submissions });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/assignment-submissions/me` && method === "GET") {
      return json(route, 200, { items: sharedWork.submissions });
    }
    if (url.pathname === `/v1/assignments/44444444-4444-4444-8444-444444444444/submissions` && method === "POST") {
      if (!Array.isArray(body.answers) || body.answers.length !== 3 || body.answers.some((answer) => !answer.questionId || !answer.response)) {
        return json(route, 400, { code: "answer_required", message: "Three real answers required" });
      }
      const prior = sharedWork.submissions.at(-1);
      if (prior && prior.status !== "returned") return json(route, 409, { code: "submission_already_active" });
      const item = {
        id: prior ? "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb" : "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        assignmentId: "44444444-4444-4444-8444-444444444444",
        clientEntityId: body.clientEntityId,
        status: "submitted",
        answers: body.answers,
        studentUserId: "66666666-6666-4666-8666-666666666666",
        studentDisplayName: "服务端学生",
        version: prior ? 2 : 1,
        previousSubmissionId: prior?.id || null,
        reviewStatus: "pending",
        score: null,
        feedback: null,
        submittedAt: "2026-10-23T12:30:00.000Z"
      };
      sharedWork.submissions.push(item);
      sharedWork.reviews.push({
        id: item.id, submissionId: item.id, assignmentId: item.assignmentId,
        classId: createdClassId, status: "pending", currentScore: null,
        revision: 1, submittedAt: item.submittedAt, updatedAt: item.submittedAt,
        studentDisplayName: item.studentDisplayName, answers: item.answers,
        submissionVersion: item.version, previousAnswers: prior?.answers || []
      });
      return json(route, 201, item);
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/variant-sets` && method === "GET") {
      return json(route, 200, { items: [], nextCursor: null });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/learning/summary` && method === "GET") {
      return json(route, 200, { items: [], nextCursor: null });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/review-cases` && method === "GET") {
      return json(route, 200, { items: sharedWork.reviews.filter((item) => item.status === "pending"), nextCursor: null });
    }
    if (url.pathname.startsWith("/v1/review-cases/") && method === "PATCH") {
      const id = url.pathname.split("/").at(-1);
      const review = sharedWork.reviews.find((item) => item.id === id);
      const submission = sharedWork.submissions.find((item) => item.id === id);
      if (!review || !submission) return json(route, 404, { code: "not_found" });
      review.status = body.decision === "return" ? "returned" : "approved";
      review.currentScore = body.score;
      submission.status = body.decision === "return" ? "returned" : "accepted";
      submission.reviewStatus = review.status;
      submission.score = body.score;
      submission.feedback = body.reason;
      return json(route, 200, review);
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/learning/sync` && method === "POST") {
      return json(route, 200, { accepted: true, nextRevision: 2, conflicts: [] });
    }
    if (activeClassId && url.pathname === `/v1/classes/${activeClassId}/invites` && method === "POST") {
      return json(route, 201, {
        id: "77777777-7777-4777-8777-777777777777",
        code: inviteCode,
        expiresAt: body.expiresAt || "2026-09-07T00:00:00.000Z",
        maxUses: body.maxUses || 1000
      });
    }
    if (url.pathname === `/v1/memberships/${membershipId}` && method === "PATCH") {
      if (body.status) memberStatus = body.status;
      return json(route, 200, {
        id: membershipId,
        classId,
        groupId: body.groupId ?? groups[0]?.id ?? null,
        userId: "66666666-6666-4666-8666-666666666666",
        displayName: "待审核学生",
        memberRole: "student",
        studentNumber: "2026001",
        status: memberStatus,
        revision: 2,
        joinedAt: "2026-08-01T00:00:00.000Z",
        updatedAt: "2026-08-01T00:01:00.000Z"
      });
    }
    if (url.pathname === "/v1/invites/join" && method === "POST") {
      return json(route, 201, { membershipId, status: "pending" });
    }
    if (url.pathname === "/v1/invites/join-anonymous" && method === "POST") {
      classes = [{
        id: createdClassId, name: "仅名称创建的物理班", grade: "高一", subject: "物理",
        schoolLabel: null, status: "active", revision: 1,
        createdAt: "2026-10-23T12:00:00.000Z", updatedAt: "2026-10-23T12:00:00.000Z"
      }];
      return json(route, 201, {
        accessToken,
        refreshToken,
        user: {
          id: "66666666-6666-4666-8666-666666666666",
          role: "student",
          displayName: body.displayName || "瀛︾敓",
          status: "active",
          mustChangePassword: false,
          deletionPending: false
        },
        membershipId,
        classId: createdClassId,
        status: "active"
      });
    }
    if (url.pathname === "/v1/account/self" && method === "PATCH") {
      return json(route, 200, {
        user: {
          id: "66666666-6666-4666-8666-666666666666",
          role: "student",
          displayName: body.displayName,
          status: "active",
          mustChangePassword: false,
          deletionPending: false
        }
      });
    }
    if (url.pathname === "/v1/auth/logout" && method === "POST") return json(route, 204, null);
    return json(route, 404, { code: "not_found", requestId: "classroom-ui-qa" });
  });
}

async function preparePage(context, role, calls) {
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(message.text());
  });
  await page.addInitScript((value) => {
    globalThis.PHYSICS_STUDIO_CLASSROOM_URL = value.role === "teacher"
      ? "https://classroom.example"
      : "";
    globalThis.PHYSICS_STUDIO_ALLOW_INSECURE_LAN = true;
    localStorage.setItem("physics-experience-v2", JSON.stringify(value));
    if (value.role === "teacher") {
      // The UI fixture represents an already authenticated teacher session;
      // keep the local PIN gate explicit without opening prompt dialogs.
      sessionStorage.setItem("physics-teacher-mode-session-v1", "unlocked");
    }
  }, experience(role));
  await installActivationStub(page);
  await installServerMock(page, role, calls);
  await page.goto(pathToFileURL(path.join(project, "index.html")).href, { waitUntil: "domcontentloaded" });
  await page.waitForFunction(() => {
    return !document.body.classList.contains("activation-pending")
      && window.PhysicsStudioApp?.getQuestions?.().length >= 1900
      && Boolean(window.PhysicsStudioClassroom);
  });
  return { page, errors };
}

async function login(page, loginName) {
  await page.locator('#classroomLoginForm input[name="login"]').fill(loginName);
  await page.locator('#classroomLoginForm input[name="password"]').fill("correct horse battery staple");
  await page.locator('#classroomLoginForm button[type="submit"]').click();
  await page.locator(".classroom-session-bar").waitFor({ state: "visible" });
}

(async () => {
  fs.mkdirSync(outputDirectory, { recursive: true });
  const browser = await launchBrowser({
    headless: true,
    args: ["--allow-file-access-from-files"]
  });
  const teacherCalls = [];
  const studentCalls = [];
  try {
    const teacherContext = await browser.newContext({ viewport: { width: 1440, height: 960 } });
    const teacher = await preparePage(teacherContext, "teacher", teacherCalls);
    await teacher.page.locator('[data-teacher-action="classroom"]').click();
    await teacher.page.locator("#classroomDialog[open]").waitFor({ state: "visible" });
    await teacher.page.locator('#classroomCreateClassForm input[name="name"]').fill("仅名称创建的物理班");
    await teacher.page.locator('#classroomCreateClassForm button[type="submit"]').click();
    try {
      await teacher.page.getByText("仅名称创建的物理班", { exact: true }).first().waitFor({ timeout: 8_000 });
    } catch (error) {
      throw new Error(`teacher create UI did not complete: ${await teacher.page.locator("#classroomContent").innerText()}`, {
        cause: error,
      });
    }
    assert.match(await teacher.page.locator(".classroom-class-head").innerText(), /仅名称创建的物理班/);
    const createCall = teacherCalls.find((call) => call.method === "POST" && call.path === "/v1/classes/anonymous");
    assert.deepEqual(createCall?.body, { name: "仅名称创建的物理班" });
    await teacher.page.locator('#classroomInviteForm button[type="submit"]').click();
    await teacher.page.locator(".classroom-invite-code").waitFor({ state: "visible" });
    assert.match(await teacher.page.locator(".classroom-invite-code").innerText(), new RegExp(inviteCode));
    assert.equal(await teacher.page.locator('#classroomInviteForm input[name="expiresAt"]').count(), 0);
    assert.equal(await teacher.page.locator('#classroomInviteForm input[name="maxUses"]').count(), 0);
    const qrCanvas = teacher.page.locator("#classroomInviteQr");
    const decodedInvite = await qrCanvas.evaluate((canvas) => {
      const context = canvas.getContext("2d");
      const image = context.getImageData(0, 0, canvas.width, canvas.height);
      return window.jsQR(image.data, image.width, image.height, { inversionAttempts: "attemptBoth" })?.data || "";
    });
    const parsedInvite = new URL(decodedInvite);
    assert.equal(parsedInvite.protocol, "physicsstudio:");
    assert.equal(parsedInvite.searchParams.get("c"), createdClassId);
    assert.equal(parsedInvite.searchParams.get("i"), inviteCode);
    assert.equal(parsedInvite.searchParams.get("h"), "classroom.example");
    const inviteQrPng = await qrCanvas.screenshot();
    await teacher.page.screenshot({ path: path.join(outputDirectory, "teacher-invite-qr.png"), fullPage: false });
    await teacher.page.locator('#classroomGroupForm input[name="name"]').fill("基础巩固组");
    await teacher.page.locator('#classroomGroupForm button[type="submit"]').click();
    await teacher.page.locator(".classroom-group-list").getByText("基础巩固组").waitFor();
    await teacher.page.locator(`[data-classroom-member="${membershipId}"][data-classroom-status="active"]`).click();
    await teacher.page.waitForTimeout(300);
    const approvedText = await teacher.page.locator("#classroomContent").innerText();
    assert.match(approvedText, /已批准学生加入。[\s\S]*已加入/, approvedText);
    await teacher.page.locator('#classroomAssignmentForm input[name="title"]').fill("三题物理专项");
    await teacher.page.locator('#classroomAssignmentForm textarea[name="target"]').fill("三题均完成真实作答，由教师批改开放题。");
    const questionChoices = teacher.page.locator(".classroom-picker-results [data-classroom-question]");
    for (let index = 0; index < 3; index += 1) await questionChoices.nth(index).check();
    await teacher.page.locator('#classroomAssignmentForm button[type="submit"]').click();
    await teacher.page.getByText("作业已由班级服务确认。", { exact: true }).waitFor();
    const publishedCall = teacherCalls.find((call) => call.method === "POST" && call.path === `/v1/classes/${createdClassId}/assignments`);
    assert.equal(publishedCall?.body?.questionIds?.length, 3);
    assert.equal(publishedCall?.body?.questionItems?.length, 3);
    assert.ok(publishedCall.body.questionItems.every((item) => item.content && item.questionType));
    await teacher.page.screenshot({ path: path.join(outputDirectory, "teacher-classroom.png"), fullPage: false });
    await teacher.page.setViewportSize({ width: 390, height: 844 });
    await teacher.page.locator("#classroomInviteQr").scrollIntoViewIfNeeded();
    const teacherMobileFit = await teacher.page.locator("#classroomDialog").evaluate((node) => ({
      clientWidth: node.clientWidth,
      scrollWidth: node.scrollWidth,
      clientHeight: node.clientHeight,
      scrollHeight: node.scrollHeight
    }));
    assert.ok(teacherMobileFit.scrollWidth <= teacherMobileFit.clientWidth + 1, JSON.stringify(teacherMobileFit));
    await teacher.page.screenshot({ path: path.join(outputDirectory, "teacher-mobile-invite.png"), fullPage: false });
    if (teacher.errors.length) console.error("teacher page errors", teacher.errors, teacherCalls.map((call) => `${call.method} ${call.path}`));
    assert.deepEqual(teacher.errors, []);

    const studentContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
    const student = await preparePage(studentContext, "student", studentCalls);
    await student.page.locator('.student-bottom-nav [data-student-view="profile"]').click();
    await student.page.locator('[data-shell-action="classroom"]').click();
    await student.page.locator("#classroomDialog[open]").waitFor({ state: "visible" });
    // A previous teacher session must never make the student entry point render
    // the teacher classroom editor. This reproduces the device-switch bug.
    await student.page.evaluate(({ accessToken: token, refreshToken: refresh, user }) => {
      sessionStorage.setItem("physics-classroom-access-token-v1", token);
      sessionStorage.setItem("physics-classroom-refresh-token-v1", refresh);
      sessionStorage.setItem("physics-classroom-user-v1", JSON.stringify(user));
    }, {
      accessToken,
      refreshToken,
      user: {
        id: "55555555-5555-4555-8555-555555555555",
        role: "teacher",
        displayName: "残留教师会话",
        status: "active"
      }
    });
    await student.page.reload({ waitUntil: "domcontentloaded" });
    await student.page.waitForFunction(() => !document.body.classList.contains("activation-pending"));
    await student.page.locator('.student-bottom-nav [data-student-view="profile"]').click();
    await student.page.locator('[data-shell-action="classroom"]').click();
    await student.page.locator("#classroomDialog[open]").waitFor({ state: "visible" });
    await student.page.locator("#classroomStudentJoinForm").waitFor({ state: "visible" });
    assert.equal(await student.page.locator("#classroomCreateClassForm").count(), 0);
    await student.page.evaluate(() => sessionStorage.clear());
    await student.page.reload({ waitUntil: "domcontentloaded" });
    await student.page.waitForFunction(() => !document.body.classList.contains("activation-pending"));
    await student.page.locator('.student-bottom-nav [data-student-view="profile"]').click();
    await student.page.locator('[data-shell-action="classroom"]').click();
    await student.page.locator("#classroomDialog[open]").waitFor({ state: "visible" });
    // A fresh student profile must see the matching add-class flow before
    // any account authentication; the invite route creates the scoped guest
    // student session in one step.
    await student.page.locator("#classroomStudentJoinForm").waitFor({ state: "visible" });
    assert.equal(await student.page.locator('#classroomStudentJoinForm input[name="login"]').count(), 0);
    assert.equal(await student.page.locator('#classroomStudentJoinForm input[name="password"]').count(), 0);
    if (false) {
    await student.page.locator('#classroomStudentJoinForm input[name="deviceName"]').fill("学生测试设备");
    }
    await student.page.locator('#classroomStudentJoinForm input[name="displayName"]').fill("李明·一班");
    await student.page.locator("#classroomStudentJoinForm #classroomInviteQrInput").setInputFiles({
      name: "classroom-invite.png",
      mimeType: "image/png",
      buffer: inviteQrPng
    });
    await student.page.locator(".classroom-session-bar").waitFor({ state: "visible" });
    try {
      await student.page.getByText("三题物理专项", { exact: true }).first().waitFor({ timeout: 6_000 });
    } catch (error) {
      throw new Error(`student assignment missing: ${await student.page.locator("#classroomContent").innerText()} | ${JSON.stringify(studentCalls.map((call) => `${call.method} ${call.path}`))}`, { cause: error });
    }
    await student.page.locator("[data-classroom-open-assignment]").first().click();
    const answerFields = student.page.locator('[data-assignment-field="response"]');
    assert.equal(await answerFields.count(), 3);
    await answerFields.nth(0).fill("2 m/s");
    await answerFields.nth(1).fill("合力改变速度");
    await answerFields.nth(2).fill("机械能守恒须检查非保守力做功");
    await student.page.locator('[data-classroom-assignment-answer-form] button[type="submit"]').click();
    await student.page.getByText("逐题作答已由服务端确认，等待教师批改。", { exact: true }).waitFor();
    assert.equal(sharedWork.submissions.length, 1);
    assert.equal(sharedWork.submissions[0].answers.length, 3);
    await teacher.page.setViewportSize({ width: 1440, height: 960 });
    await teacher.page.locator('[data-classroom-action="refresh"]').click();
    const analyticsBeforeReview = teacher.page.locator('[data-classroom-analytics]');
    await analyticsBeforeReview.waitFor({ timeout: 6_000 });
    const analyticsBeforeReviewText = await analyticsBeforeReview.innerText();
    assert.match(analyticsBeforeReviewText, /班级学情分析/);
    assert.match(analyticsBeforeReviewText, /待人工复核\s*1/);
    assert.match(analyticsBeforeReviewText, /暂无已评分证据/);
    assert.match(analyticsBeforeReviewText, /证据不足/);
    assert.equal(await analyticsBeforeReview.locator("code").first().textContent(), "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
    try {
      await teacher.page.locator('[data-classroom-review-form]').waitFor({ timeout: 6_000 });
    } catch (error) {
      throw new Error(`teacher review missing: ${await teacher.page.locator("#classroomContent").innerText()} | reviews=${JSON.stringify(sharedWork.reviews)} | calls=${JSON.stringify(teacherCalls.map((call) => `${call.method} ${call.path}`))}`, { cause: error });
    }
    assert.match(await teacher.page.locator('[data-classroom-review-form]').innerText(), /合力改变速度/);
    await teacher.page.locator('[data-classroom-review-form] select[name="decision"]').selectOption("return");
    await teacher.page.locator('[data-classroom-review-form] input[name="score"]').fill("60");
    await teacher.page.locator('[data-classroom-review-form] textarea[name="reason"]').fill("请补充受力对象和规律适用条件。");
    await teacher.page.locator('[data-classroom-review-form] button[type="submit"]').click();
    try {
      await teacher.page.getByText("教师复核决定已提交。", { exact: true }).waitFor({ timeout: 6_000 });
    } catch (error) {
      throw new Error(`teacher review submission failed: ${await teacher.page.locator("#classroomContent").innerText()} | calls=${JSON.stringify(teacherCalls.slice(-5).map((call) => `${call.method} ${call.path}`))} | errors=${JSON.stringify(teacher.errors)}`, { cause: error });
    }
    await student.page.locator('[data-classroom-action="refresh"]').click();
    await student.page.getByText("教师退回，待订正", { exact: false }).waitFor();
    await student.page.locator('[data-assignment-field="response"]').nth(1).fill("以小车为研究对象，合力不为零，依据牛顿第二定律加速度不为零。");
    await student.page.locator('[data-classroom-assignment-answer-form] button[type="submit"]').click();
    await student.page.getByText("逐题作答已由服务端确认，等待教师批改。", { exact: true }).waitFor();
    assert.equal(sharedWork.submissions.length, 2);
    assert.equal(sharedWork.submissions[0].status, "returned");
    assert.equal(sharedWork.submissions[1].version, 2);
    await teacher.page.locator('[data-classroom-action="refresh"]').click();
    await teacher.page.locator('[data-classroom-review-form]').waitFor();
    assert.match(await teacher.page.locator('[data-classroom-review-form]').innerText(), /合力改变速度/);
    assert.match(await teacher.page.locator('[data-classroom-review-form]').innerText(), /牛顿第二定律/);
    assert.equal(
      studentCalls.filter((call) => call.method === "POST" && call.path === "/v1/invites/join-anonymous").length,
      1,
      "QR image decoding must call the same anonymous join endpoint exactly once",
    );
    const mobileFit = await student.page.locator("#classroomDialog").evaluate((node) => ({
      clientWidth: node.clientWidth,
      scrollWidth: node.scrollWidth,
      clientHeight: node.clientHeight,
      scrollHeight: node.scrollHeight
    }));
    assert.ok(mobileFit.scrollWidth <= mobileFit.clientWidth + 1, JSON.stringify(mobileFit));
    assert.ok(mobileFit.scrollHeight >= mobileFit.clientHeight, JSON.stringify(mobileFit));
    await student.page.screenshot({ path: path.join(outputDirectory, "student-join.png"), fullPage: false });
    if (student.errors.length) console.error("student page errors", student.errors, studentCalls.map((call) => `${call.method} ${call.path}`));
    assert.deepEqual(student.errors, []);
    await studentContext.close();
    await teacherContext.close();

    const mutations = [...teacherCalls, ...studentCalls].filter((call) => ["POST", "PATCH"].includes(call.method));
    assert.ok(mutations.length >= 6, JSON.stringify(mutations.map((call) => `${call.method} ${call.path}`)));
    assert.ok(mutations.every((call) => /^[\x21-\x7e]{16,128}$/.test(call.headers["idempotency-key"] || "")));
    const protectedCalls = [...teacherCalls, ...studentCalls].filter((call) => !call.path.startsWith("/v1/auth/") && call.path !== "/v1/classes/anonymous" && call.path !== "/v1/invites/join-anonymous");
    assert.ok(protectedCalls.every((call) => [
      `Bearer ${accessToken}`,
      `Owner ${ownerCapability}`
    ].includes(call.headers.authorization)));
    console.log(JSON.stringify({
      status: "passed",
      teacherMutations: teacherCalls.filter((call) => ["POST", "PATCH"].includes(call.method)).map((call) => call.path),
      studentMutations: studentCalls.filter((call) => ["POST", "PATCH"].includes(call.method)).map((call) => call.path),
      inviteCodeShownOnce: true,
      directGuestJoin: true,
      teacherMobileFit,
      mobileFit,
      screenshots: fs.readdirSync(outputDirectory).filter((name) => name.endsWith(".png")).sort()
    }, null, 2));
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
