// Generated from version.json; release builds regenerate this file.
globalThis.PHYSICS_STUDIO_VERSION = Object.freeze({"appVersion":"4.0.2","stateVersion":10,"reportFormatVersion":4,"feedbackEmail":"luo865265@gmail.com","classroomClientVersion":"4.0.2","androidUserAgentVersion":"4.0.2"});
